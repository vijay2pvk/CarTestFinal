# CarFit Test

CarFit test developed using protocol oriented MVVM Architecture.

## Functionalities

- Calendar view will be shown on press of Navigation bar calendar button and hidden on tap on outside of calendar view
- Calendar view will scroll to today date when the selected month is this month else it will scroll to 1st date of the month (If any scroll made on previous selection)
- Home screen which displays cleaner list for the selected date with given acceptance criteria guidelines
- Home screen title will be shown with respect to acceptance criteria guidelines
- Added pull to refresh to Home screen which has cleaner list for the day
- Added JSONToModelTransformer class containing Generic method which can convert Json to Model

## Test

- App can be tested with dates Nov - 29th, 30th  & Dec - 1st, 5th, 6th, 7th, 8th, 9th, 10th
- Unit test code coverage of 58%

## Requirements
- iOS 13.0+
- Xcode 11.3+
- Swift 5+

## Note

- Implemented MVVM architecture for all views
- Added service classes too which can be used in future when we need to request API's
- No 3rd party libraries used as per assignment restriction guidelines
- Covered only few unit test cases on View Models due to time limit. 

## ToDo

- More unit test cases and code coverage.
- Write UITest cases. 
