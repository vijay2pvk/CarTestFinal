//
//  CalendarViewModel.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 06/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation
import UIKit

protocol CalendarViewModelRepresentable {
    var selectedDateStr: String? { get set }
    var selectedIndex: IndexPath? { get set }

    var monthYearStr: String { get }

    func viewModelForItem(at indexPath: IndexPath) -> DayCellViewModel
    func scrollToIndex() -> IndexPath
    func calendarListCount() -> Int

    func leftArrowPressEvent()
    func rightArrowPressEvent()
}

class CalendarViewModel: CalendarViewModelRepresentable {
    //MARK:- Properties
    var monthYearStr: String
    var noOfDaysInMonth = 0
    var todayStr: String
    var selectedDateStr: String?
    var currentDay = 0
    var currentMonth = 0
    var currentYear = 0
    var calendarArray = [DayModel]()
    var selectedIndex: IndexPath?

    init() {
        currentDay = Calendar.current.component(.day, from: Date())
        currentMonth = Calendar.current.component(.month, from: Date())
        currentYear = Calendar.current.component(.year, from: Date())

        todayStr = DateHelper.dateAsString(Date(), format: "yyyy-MM-dd")
        selectedDateStr = todayStr
        selectedIndex = IndexPath(item: currentDay - 1, section: 0)
        self.monthYearStr = DateHelper.dateAsString(Date(), format: "MMM yyyy")
        self.calendarArray = arrayOfDates()
    }

    // Get list of dates for the selected month
    func arrayOfDates() -> [DayModel] {
        let monthStr = currentMonth < 10 ? "0\(currentMonth)" : "\(currentMonth)"
        let dateStr = "\(currentYear)-\(monthStr)-01"

        let monthStartDate = DateHelper.dateFor(dateStr: dateStr, format: "yyyy-MM-dd")
        let dateComponents = Calendar.current.dateComponents([.year, .month], from: monthStartDate)
        let startDate = Calendar.current.date(from: dateComponents)!

        let calendar = Calendar.current
        var offset = DateComponents()
        var dates = [DayModel]()

        noOfDaysInMonth = DateHelper.getDaysFor(month: currentMonth, year: currentYear)

        for i in 0..<noOfDaysInMonth {
            offset.day = i
            let date: Date? = calendar.date(byAdding: offset, to: startDate)
            let dateStr = DateHelper.dateAsString(date!, format: "d EEE")
            let arr = dateStr.components(separatedBy: " ")
            let fullDateStr = DateHelper.dateAsString(date!, format: "yyyy-MM-dd")

            let dayModel = DayModel(day: arr[0], weekDay: arr[1], date: fullDateStr)
            dates.append(dayModel)
        }

        self.monthYearStr = DateHelper.dateAsString(startDate, format: "MMM yyyy")
        return dates
    }

    func scrollToIndex() -> IndexPath {
        guard let index = calendarArray.firstIndex(where: {$0.date == todayStr}) else {
            return IndexPath(item: 0, section: 0)
        }
        return IndexPath(item: index, section: 0)
    }
    
    //MARK:- Protocol Implementation
    func viewModelForItem(at indexPath: IndexPath) -> DayCellViewModel {
        let dayViewModel = DayCellViewModel(dayCellModel: self.calendarArray[indexPath.row])
        let dayModel = self.calendarArray[indexPath.row]

        if (selectedDateStr == nil && todayStr == dayModel.date) || (selectedDateStr == dayModel.date && selectedIndex == nil) {
            selectedDateStr = dayModel.date
            selectedIndex = IndexPath(item: currentDay - 1, section: 0)
        }
        return dayViewModel
    }

    func calendarListCount() -> Int {
        return self.calendarArray.count
    }

    func leftArrowPressEvent() {
        currentMonth -= 1
        if currentMonth < 1 {
            currentMonth = 12
            currentYear -= 1
        }
        self.selectedDateStr = nil
        self.selectedIndex = nil
        self.calendarArray = arrayOfDates()
    }

    func rightArrowPressEvent() {
        currentMonth += 1
        if currentMonth > 12 {
            currentMonth = 1
            currentYear += 1
        }
        self.selectedDateStr = nil
        self.selectedIndex = nil
        self.calendarArray = arrayOfDates()
    }
}
