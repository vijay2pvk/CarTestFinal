//
//  DayCellModel.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 06/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation
import UIKit

/// DayCellViewModelRepresentable - represents the view display infromation.
protocol DayCellViewModelRepresentable {
    var day: String { get }
    var weekday: String { get }
    var date: String { get }
}

struct DayCellViewModel: DayCellViewModelRepresentable {

    let day: String
    let weekday: String
    let date: String

    init(dayCellModel: DayModel) {
        self.day = dayCellModel.day
        self.weekday = dayCellModel.weekday
        self.date = dayCellModel.date
    }
}
