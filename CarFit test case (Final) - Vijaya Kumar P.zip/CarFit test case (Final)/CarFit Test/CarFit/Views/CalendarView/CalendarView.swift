//
//  CalendarView.swift
//  Calendar
//
//  Test Project
//

import UIKit

protocol CalendarDelegate: class {
    func getSelectedDate(_ date: String)
}

class CalendarView: UIView {
    //MARK:- IBOutlets
    @IBOutlet weak var monthAndYear: UILabel!
    @IBOutlet weak var leftBtn: UIButton!
    @IBOutlet weak var rightBtn: UIButton!
    @IBOutlet weak var daysCollectionView: UICollectionView!

    //MARK:- Properties
    private let cellID = "DayCell"
    weak var delegate: CalendarDelegate?

    private var viewModel: CalendarViewModelRepresentable = CalendarViewModel()
    private var selectedCell: DayCell?

    //MARK:- Initialize calendar
    private func initialize() {
        let nib = UINib(nibName: self.cellID, bundle: nil)
        self.daysCollectionView.register(nib, forCellWithReuseIdentifier: self.cellID)
        self.daysCollectionView.delegate = self
        self.daysCollectionView.dataSource = self

        self.monthAndYear.text = viewModel.monthYearStr
        self.daysCollectionView.reloadData()
        self.daysCollectionView.selectItem(at: viewModel.scrollToIndex(), animated: true, scrollPosition: .left)
    }
    
    //MARK:- Change month when left and right arrow button tapped
    @IBAction func arrowTapped(_ sender: UIButton) {
        if sender == rightBtn {
            viewModel.rightArrowPressEvent()
        } else {
            viewModel.leftArrowPressEvent()
        }
        self.monthAndYear.text = viewModel.monthYearStr
        self.selectedCell = nil
        self.daysCollectionView.reloadData()
        self.daysCollectionView.selectItem(at: viewModel.scrollToIndex(), animated: true, scrollPosition: .left)
    }
}

//MARK:- Calendar collection view delegate and datasource methods
extension CalendarView: UICollectionViewDataSource, UICollectionViewDelegate {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.calendarListCount()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: self.cellID, for: indexPath) as! DayCell
        let cellViewModel = self.viewModel.viewModelForItem(at: indexPath)
        cell.configure(with: cellViewModel)

        if viewModel.selectedIndex == indexPath {
            self.selectedCell = cell
            cell.dayView.backgroundColor = UIColor.daySelected
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                collectionView.delegate?.collectionView!(collectionView, didSelectItemAt: indexPath)
            }
        }

        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let cell = collectionView.cellForItem(at: indexPath) as? DayCell,
            let dayModel = cell.dayCellModel else { return }

        // Safely set the existing selected cell with clear color if its not in visible region during didDeselectItemAt call back
        if let selectedCell = selectedCell {
            selectedCell.dayView.backgroundColor = UIColor.clear
        }

        self.selectedCell = cell
        cell.dayView.backgroundColor = UIColor.daySelected
        viewModel.selectedDateStr = dayModel.date
        viewModel.selectedIndex = indexPath
        self.delegate?.getSelectedDate(dayModel.date)
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        guard let cell = collectionView.cellForItem(at: indexPath) as? DayCell else { return }
        cell.dayView.backgroundColor = UIColor.clear
    }
}

//MARK:- Add calendar to the view
extension CalendarView {
    public class func addCalendar(_ superView: UIView) -> CalendarView? {
        var calendarView: CalendarView?
        if calendarView == nil {
            calendarView = UINib(nibName: "CalendarView", bundle: nil).instantiate(withOwner: self, options: nil).last as? CalendarView
            guard let calenderView = calendarView else { return nil }
            calendarView?.frame = CGRect(x: 0, y: 0, width: superView.bounds.size.width, height: superView.bounds.size.height)
            superView.addSubview(calenderView)
            calenderView.initialize()
            return calenderView
        }
        return nil
    }
}
