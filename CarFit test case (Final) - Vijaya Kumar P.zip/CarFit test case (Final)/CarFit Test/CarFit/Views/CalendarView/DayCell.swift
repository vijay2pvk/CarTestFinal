//
//  DayCell.swift
//  Calendar
//
//  Test Project
//

import UIKit

class DayCell: UICollectionViewCell {
    @IBOutlet weak var dayView: UIView!
    @IBOutlet weak var day: UILabel!
    @IBOutlet weak var weekday: UILabel!
    var dayCellModel: DayCellViewModel?

    override func awakeFromNib() {
        super.awakeFromNib()
        self.dayView.layer.cornerRadius = self.dayView.frame.width / 2.0
        self.dayView.backgroundColor = .clear
    }

    // Configure with model data
    func configure(with viewModel: DayCellViewModel?) {
        guard let dayModel = viewModel else { return }

        self.dayCellModel = dayModel
        self.dayView.backgroundColor = UIColor.clear
        self.day.text = dayModel.day
        self.weekday.text = dayModel.weekday
    }
}
