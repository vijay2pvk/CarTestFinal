//
//  HomeTableViewCell.swift
//  Calendar
//
//  Test Project
//

import UIKit
import CoreLocation

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var customer: UILabel!
    @IBOutlet weak var statusView: UIView!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var tasks: UILabel!
    @IBOutlet weak var arrivalTime: UILabel!
    @IBOutlet weak var destination: UILabel!
    @IBOutlet weak var timeRequired: UILabel!
    @IBOutlet weak var distance: UILabel!

    private var viewModel: HomeTableCellViewModelRepresentable?

    override func awakeFromNib() {
        super.awakeFromNib()
        self.bgView.layer.cornerRadius = 10.0
        self.statusView.layer.cornerRadius = self.status.frame.height / 2.0
        self.statusView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMinXMaxYCorner]
    }

    // Configure with model data
    func configure(with viewModel: HomeTableCellViewModelRepresentable?) {
        guard let dayTask = viewModel else { return }

        self.viewModel = dayTask
        customer.text = dayTask.name
        status.text = dayTask.status
        statusView.backgroundColor = dayTask.statusBgColour
        tasks.text = dayTask.tasks
        arrivalTime.text = dayTask.arrivalTime
        destination.text = dayTask.destination
        timeRequired.text = dayTask.timeRequired
        distance.text = dayTask.distance
    }
}
