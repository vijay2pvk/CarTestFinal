//
//  HomeTableViewCellModel.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 04/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation
import UIKit

/// HomeTableCellViewModelRepresentable - represents the view display infromation.
protocol HomeTableCellViewModelRepresentable {
    var name: String { get }
    var status: String { get }
    var statusBgColour: UIColor { get }
    var tasks: String { get }
    var arrivalTime: String { get }
    var destination: String { get }
    var timeRequired: String { get }
    var distance: String { get }
}

struct HomeTableCellViewModel: HomeTableCellViewModelRepresentable {
    //MARK:- Protocol properties
    var name: String = ""
    var status: String = ""
    var statusBgColour = UIColor()
    var tasks: String = ""
    var arrivalTime: String = ""
    var destination: String = ""
    var timeRequired: String = ""
    var distance: String = ""
    var dayTasks: DayTasks

    //MARK:- Initializer
    init(dayTasks: DayTasks) {
        self.dayTasks = dayTasks
        name = formatName()
        status = self.dayTasks.visitState.map { $0.rawValue } ?? ""
        statusBgColour = statusViewColor()
        tasks = formatTasks()
        arrivalTime = formatArrivalTime()
        destination = formatDestination()
        timeRequired = formatTimeRequired()
        distance = self.dayTasks.distance ?? ""
    }

    //MARK:- Properties formatter
    private func formatName() -> String {
        let firstName = self.dayTasks.houseOwnerFirstName ?? ""
        let lastName = self.dayTasks.houseOwnerLastName ?? ""
        let fullName = firstName + ((firstName.count > 0 && lastName.count > 0) ? " " + lastName : lastName)
        return fullName
    }

    private func formatTasks() -> String {
        guard let tasks = self.dayTasks.tasks else { return "" }

        var taskStr = ""
        for task in tasks {
            taskStr = taskStr + ((taskStr.count > 0) ? ", " : "")
            taskStr = taskStr + (task.title ?? "")
        }
        return taskStr
    }

    private func formatTimeRequired() -> String {
        guard let tasks = self.dayTasks.tasks else { return "" }

        var time = 0
        for task in tasks {
            time += Int(task.timesInMinutes ?? 0)
        }
        return "\(time)"
    }

    private func formatArrivalTime() -> String {
        guard let dateStr = self.dayTasks.startTimeUtc else { return "" }

        let date =  DateHelper.dateFor(dateStr: dateStr, format: "yyyy-MM-dd'T'HH:mm:ss")
        var timeStr = DateHelper.dateAsString(date, format: "HH:mm")

        if let expectedTime = self.dayTasks.expectedTime {
            let separatorArray = expectedTime.split(separator: "/")
            for (index,time) in separatorArray.enumerated() {
                if index == 0 && timeStr.count > 0 { timeStr = timeStr + " / " }
                timeStr = timeStr + time

                if separatorArray.indices.contains(index+1){
                    timeStr = timeStr + " - "
                }
            }
        }
        return timeStr
    }

    private func formatDestination() -> String {
        let address = self.dayTasks.houseOwnerAddress ?? ""
        let city = self.dayTasks.houseOwnerCity ?? ""
        let zip = self.dayTasks.houseOwnerZip ?? ""

        var destinationStr = address + (address.count > 0 && city.count > 0 ? " " + city : city)
        destinationStr = destinationStr + (destinationStr.count > 0 && zip.count > 0 ? " " + zip : zip)
        return destinationStr
    }

    private func statusViewColor() -> UIColor {
        guard let visitState = self.dayTasks.visitState else { return UIColor.todoOption }

        switch visitState {
        case .todo:
            return UIColor.todoOption
        case .inprogress:
            return UIColor.inProgressOption
        case .done:
            return UIColor.doneOption
        case .rejected:
            return UIColor.rejectedOption
        }
    }
}
