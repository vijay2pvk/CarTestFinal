//
//  TaskStatus.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 05/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation

enum TaskStatus: String, Codable {
    case todo = "ToDo"
    case inprogress = "InProgress"
    case done = "Done"
    case rejected = "Rejected"
}
