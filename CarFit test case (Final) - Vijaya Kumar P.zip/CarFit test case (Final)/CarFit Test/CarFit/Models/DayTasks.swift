//
//  Tasks.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 04/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation

struct DayTasks: Codable {
    var visitId: String?
    var homeBobEmployeeId: String?
    var houseOwnerId: String?
    var isBlocked: Bool?
    var startTimeUtc: String?
    var endTimeUtc: String?
    var title: String?
    var isReviewed: Bool?
    var isFirstVisit: Bool?
    var isManual: Bool?
    var visitTimeUsed: Int?
    var rememberToday: Bool?
    var houseOwnerFirstName: String?
    var houseOwnerLastName: String?
    var houseOwnerMobilePhone: String?
    var houseOwnerAddress: String?
    var houseOwnerZip: String?
    var houseOwnerCity: String?
    var houseOwnerLatitude: Double?
    var houseOwnerLongitude: Double?
    var isSubscriber: Bool?
    var rememberAlways: Bool?
    var professional: String?
    var visitState: TaskStatus?
    var stateOrder: Int?
    var expectedTime: String?
    var tasks: [Tasks]?
    var houseOwnerAssets: [HouseOwnerAssets]?
    var visitAssets: [VisitAssets]?
    var visitMessages: [VisitMessages]?
    var distance: String?
}
