//
//  DayCellModel.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 06/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import UIKit

struct DayModel {
    var day: String
    var weekday: String
    var date: String
    var dayViewBgColour: UIColor = .clear

    init(day: String, weekDay: String, date: String) {
        self.day = day
        self.weekday = weekDay
        self.date = date
    }
}
