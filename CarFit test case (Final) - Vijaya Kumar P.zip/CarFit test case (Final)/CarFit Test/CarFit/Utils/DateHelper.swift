//
//  Formatter.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 05/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation

class DateHelper {
    // Convert string to date
    static func dateFor(dateStr: String, format: String) -> Date {
        let formatter = DateFormatter()
        formatter.timeZone = TimeZone.current
        formatter.dateFormat = format 
        return formatter.date(from: dateStr)!
    }

    // Convert string to date
    static func dateAsString(_ date: Date, format: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format

        return dateFormatter.string(from: date)
    }

    // Get number of days for the month for the given year
    static func getDaysFor(month: Int,year: Int) -> Int {
        let dateComponents = DateComponents(year: year, month: month)

        if let date = Calendar.current.date(from: dateComponents) {
            let range = Calendar.current.range(of: .day, in: .month, for: date)!
            let days = range.count

            return days
        }
        return 0
    }
}
