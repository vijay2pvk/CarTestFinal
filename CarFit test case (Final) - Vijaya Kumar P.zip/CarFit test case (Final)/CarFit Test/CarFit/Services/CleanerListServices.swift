//
//  LunchServices.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 04/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation

protocol CleanerListServiceRequestType {
    func getCleanerList(completion: @escaping (Result<CleanerListData, Error>) -> Void)
}

class CleanerListServices: CleanerListServiceRequestType {
    let apiClient: APIClientProtocol

    init(apiClient: APIClientProtocol) {
        self.apiClient = apiClient
    }

    func getCleanerList(completion: @escaping (Result<CleanerListData, Error>) -> Void) {
        apiClient.executeRequest(with: CleanerListEndPoints.getCleanerlist) { result in
            switch result {
            case .failure(let error):
                return completion(.failure(error))
            case .success(let data):
                let transformedResult = JSONToModelTransformer.convert(data: data, to: CleanerListData.self)
                return completion(transformedResult)
            }
        }
    }
}
