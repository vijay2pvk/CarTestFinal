//
//  JSONToModelTransformer.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 04/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation

struct JSONToModelTransformer {
    static func convert<T: Codable>(data: Data, to modelType: T.Type = T.self) -> Result<T, Error> {
        do {
            let model = try JSONDecoder().decode(T.self, from: data)
            return .success(model)
        } catch let error {
            return .failure(error)
        }
    }
}
