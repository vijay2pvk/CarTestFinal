//
//  APIClient.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 04/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation

class APIClient: APIClientProtocol{
    static let shared = APIClient()
    let apiSession: APISessionProtocol = APISession()
    
    private init() { }

    func executeRequest(with endpoint: EndPointType, completion: @escaping (Result<Data, Error>) -> Void) {
        guard let url = endpoint.finalURL else {
            let result: Result<Data, Error> = .failure(APIClientError.cannotFormURL)
            completion(result)
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = endpoint.httpMethod.type

        if (endpoint.httpMethod == .put || endpoint.httpMethod == .post),
            let parameters = endpoint.parameters {
            let jsonData = try? JSONSerialization.data(withJSONObject: parameters)
            request.httpBody = jsonData
        }

        request.addValue(endpoint.contentType, forHTTPHeaderField: "Content-Type")

        apiSession.executeDataTask(with: request) { (data, response, error) in
            guard
                let httpResponse = response as? HTTPURLResponse,
                httpResponse.statusCode == 200
                else {
                    completion(.failure(APIClientError.serverError))
                    return
            }

            if let error = error {
                completion(.failure(error))
                return
            }

            guard let data = data else {
                completion(.failure(APIClientError.unknown))
                return
            }
            completion(.success(data))
        }
    }
}
