//
//  CleanerListStubDataGenerator.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 04/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation

class CleanerListStubDataGenerator {

    class func getData(fileName: String, type: String) -> Data {
        let path = Bundle(for: CleanerListStubDataGenerator.self).path(forResource: fileName, ofType: type)!
        let data = try! Data(contentsOf: URL(fileURLWithPath: path), options: .alwaysMapped)
        return data
    }

    class func getCleanerList() -> (Result<CleanerListData, Error>) {
        let result = JSONToModelTransformer.convert(data: getData(fileName: "carfit", type: "json"), to: CleanerListData.self)
        switch result {
        case .failure(let error):
            return .failure(error)
        case .success(let cleanerListData):
            return .success(cleanerListData)
        }
    }
}
