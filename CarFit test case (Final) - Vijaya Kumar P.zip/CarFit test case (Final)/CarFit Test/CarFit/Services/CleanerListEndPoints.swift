//
//  LunchEndPoints.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 04/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation

/// Can add more cases to extend the functionality in future

enum HTTPMethod: String {
    case delete = "DELETE"
    case get = "GET"
    case post = "POST"
    case put = "PUT"
    
    var type: String {
        return self.rawValue
    }
}

protocol EndPointType {
    var baseURLString: String { get }
    var path: String { get }
    var contentType: String { get }
    var httpMethod: HTTPMethod { get }
    var parameters: [String: Any]? { get }
}

extension EndPointType {
    var contentType: String {
        return "application/json"
    }

    var finalURL: URL? {
        return URL(string: baseURLString + path)
    }
}

enum CleanerListEndPoints: EndPointType {

    case getCleanerlist

    var baseURLString: String {
        return "somebaseurl"
    }

    var path: String {
        switch self {
        case .getCleanerlist:
            return "/cleanerlist.json"
        }
    }

    var httpMethod: HTTPMethod {
        var methodType: HTTPMethod
        
        switch self {
        case .getCleanerlist:
            methodType = .get
        }
        return methodType
    }

    var parameters: [String : Any]? {
        switch self {
        default:
            return nil
        }
    }
}
