//
//  CleanerListViewModel.swift
//  CarFit
//
//  Created by Pandurangan, Vijaya Kumar on 04/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import Foundation
import CoreLocation

protocol CleanerListViewModelRepresentable {
    func selectedDayTasksListCount() -> Int 
    func viewModelForItem(at indexPath: IndexPath) -> HomeTableCellViewModel?
    func fetchCleanerList(completion: @escaping (Result<CleanerListData, Error>) -> Void)
    func filterListFor(date dateStr: String)
    func getNavbarTitleFor(selDate: String) -> String
}

class CleanerListViewModel: CleanerListViewModelRepresentable {
    //MARK:- Properties
    private var allDayTasksList = [DayTasks]()
    private var selectedDayTasksList = [DayTasks]()

    //MARK:- Transform Data
    private func transform(_ model: CleanerListData) {
        self.allDayTasksList = model.data
    }

    //MARK:- Protocol Method Implementation
    func selectedDayTasksListCount() -> Int {
        return selectedDayTasksList.count
    }
    
    func viewModelForItem(at indexPath: IndexPath) -> HomeTableCellViewModel? {
        let cleanerListViewModel = HomeTableCellViewModel(dayTasks: selectedDayTasksList[indexPath.row])
        return cleanerListViewModel
    }

    func fetchCleanerList(completion: @escaping (Result<CleanerListData, Error>) -> Void) {
        let result = CleanerListStubDataGenerator.getCleanerList()

        switch result {
        case .failure(let error):
            completion(.failure(error))
        case .success(let cleanerListData):
            transform(cleanerListData)
            completion(.success(cleanerListData))
        }
    }

    func filterListFor(date dateStr: String) {
        // Filter array with selected date and sort wrt to start time
        let filteredSortedArray = allDayTasksList.filter { ($0.startTimeUtc?.split(separator: "T").first ?? "") == dateStr }.sorted(by: { (day1, day2) -> Bool in
            guard let dayStr1 = day1.startTimeUtc, let dayStr2 = day2.startTimeUtc else { return false }
            let date1 = DateHelper.dateFor(dateStr: dayStr1, format: "yyyy-MM-dd'T'HH:mm:ss")
            let date2 = DateHelper.dateFor(dateStr: dayStr2, format: "yyyy-MM-dd'T'HH:mm:ss")
            return date1.compare(date2) == .orderedAscending
            })
        selectedDayTasksList.removeAll()

        // Calculate distance
        for index in filteredSortedArray.indices {
            if index == 0 {
                var dayTask = filteredSortedArray[index]
                dayTask.distance = "0 km"
                selectedDayTasksList.append(dayTask)
            } else {
                var dayTask1 = filteredSortedArray[index]
                let dayTask2 = filteredSortedArray[index-1]
                let distance = calculateDistance(dayTask1: dayTask1, dayTask2: dayTask2)
                dayTask1.distance = distance
                selectedDayTasksList.append(dayTask1)
            }
        }
    }

    func calculateDistance(dayTask1: DayTasks, dayTask2: DayTasks) -> String {
        guard let lat1 = dayTask1.houseOwnerLatitude, let lng1 = dayTask1.houseOwnerLongitude,
            let lat2 = dayTask2.houseOwnerLatitude, let lng2 = dayTask2.houseOwnerLongitude else { return "" }

        let location1 = CLLocation(latitude: lat1 , longitude: lng1)
        let location2 = CLLocation(latitude: lat2 , longitude: lng2)

        //Measuring distance (in Km)
        let distance = String(format: "%.1f Km", location1.distance(from: location2) / 1000)
        return distance
    }

    func getNavbarTitleFor(selDate: String) -> String {
        let todayStr = DateHelper.dateAsString(Date(), format: "yyyy-MM-dd")
        return (selDate == todayStr ? "I DAG" : selDate)
    }
}
