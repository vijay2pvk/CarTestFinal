//
//  ViewController.swift
//  Calendar
//
//  Test Project
//

import UIKit

class HomeViewController: UIViewController, AlertDisplayer {

    //MARK:- IBOutlets
    @IBOutlet var navBar: UINavigationBar!
    @IBOutlet var calendarView: UIView!
    @IBOutlet weak var calendar: UIView!
    @IBOutlet weak var calendarButton: UIBarButtonItem!
    @IBOutlet weak var workOrderTableView: UITableView!
    @IBOutlet weak var calendarViewTopConstraint: NSLayoutConstraint!
    @IBOutlet weak var workOrderTableViewTopContraint: NSLayoutConstraint!

    //MARK:- Properties
    private let cellID = "HomeTableViewCell"
    private var viewModel: CleanerListViewModelRepresentable = CleanerListViewModel()
    private let refreshControl = UIRefreshControl()

    //MARK:- Life Cycle
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.addCalendar()
        fetchData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navBar.topItem?.title = "I DAG"
        self.setupUI()
        self.setupRefreshController()
    }
    
    //MARK:- Add calender to view
    private func addCalendar() {
        if let calendar = CalendarView.addCalendar(self.calendar) {
            calendar.delegate = self
        }
    }

    //MARK:- UI setups
    private func setupUI() {
        self.navBar.transparentNavigationBar()
        let nib = UINib(nibName: self.cellID, bundle: nil)
        self.workOrderTableView.register(nib, forCellReuseIdentifier: self.cellID)
        self.workOrderTableView.rowHeight = UITableView.automaticDimension
        self.workOrderTableView.estimatedRowHeight = 170

        workOrderTableView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(gestureToHideCalendarView)))
    }

    private func setupRefreshController() {
        if #available(iOS 10.0, *) {
            self.workOrderTableView.refreshControl = refreshControl
        } else {
            self.workOrderTableView.addSubview(refreshControl)
        }
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        refreshControl.tintColor = UIColor.refreshIndicator
        refreshControl.attributedTitle = NSAttributedString(string: "Fetching Data ...")
    }

    @objc private func refreshData(_ sender: Any) {
        fetchData()
    }

    //MARK:- Show calendar when tapped, Hide the calendar when tapped outside the calendar view
    @IBAction func calendarTapped(_ sender: UIBarButtonItem) {
        showCalendarView()
    }

    fileprivate func showCalendarView() {
        self.calendarViewTopConstraint.constant = 0
        UIView.animate(withDuration: 0.45, delay: 0.0, options: .curveEaseIn, animations: {
            self.view.layoutIfNeeded()
        })

        self.workOrderTableViewTopContraint.constant = 112
        UIView.animate(withDuration: 0.35, delay: 0.0, options: .curveEaseIn, animations: {
            self.view.layoutIfNeeded()
        })
    }

    @objc fileprivate func gestureToHideCalendarView() {
        self.calendarViewTopConstraint.constant = -200
        UIView.animate(withDuration: 0.45, delay: 0.0, options: .curveEaseIn, animations: {
            self.view.layoutIfNeeded()
        })

        self.workOrderTableViewTopContraint.constant = 30
        UIView.animate(withDuration: 0.35, delay: 0.0, options: .curveEaseIn, animations: {
            self.view.layoutIfNeeded()
        })
    }

    // MARK: - API Request
    @objc private func fetchData() {
        viewModel.fetchCleanerList {[weak self] result in
            guard let strongSelf = self else { return }

            switch result {
            case .failure(let error):
                strongSelf.displayAlert(with: "Error", message: error.localizedDescription, actions: [UIAlertAction(title: "OK", style: .cancel, handler: nil)])
            case .success:
                strongSelf.workOrderTableView.reloadData()
            }
            strongSelf.refreshControl.endRefreshing()
        }
    }

    //MARK:- Set NavigationBar Title
    func setNavigationBarTitle(selDate: String) {
        self.navBar.topItem?.title = viewModel.getNavbarTitleFor(selDate: selDate)
    }
}


//MARK:- Tableview delegate and datasource methods
extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.selectedDayTasksListCount()
    }
 
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: self.cellID, for: indexPath) as! HomeTableViewCell
        let cellViewModel = self.viewModel.viewModelForItem(at: indexPath)
        cell.configure(with: cellViewModel)
        return cell
    }
}

//MARK:- Get selected calendar date
extension HomeViewController: CalendarDelegate {
    func getSelectedDate(_ date: String) {
        viewModel.filterListFor(date: date)
        setNavigationBarTitle(selDate: viewModel.getNavbarTitleFor(selDate: date))
        workOrderTableView.reloadData()
    }
}
