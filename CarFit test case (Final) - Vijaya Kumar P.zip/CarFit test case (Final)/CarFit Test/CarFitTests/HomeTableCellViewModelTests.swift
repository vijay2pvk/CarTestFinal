//
//  HomeTableCellViewModelTests.swift
//  CarFitTests
//
//  Created by Pandurangan, Vijaya Kumar on 07/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import XCTest
@testable import CarFit

class HomeTableCellViewModelTests: XCTestCase {
    
    var sut: HomeTableCellViewModel!
    
    override func setUp() {

        let tasks = Tasks(taskId: nil, title: "Pudsning indvendig", isTemplate: nil, timesInMinutes: 25, price: nil, paymentTypeId: nil, createDateUtc: nil, lastUpdateDateUtc: nil, paymentTypes: nil)

        let dayTask = DayTasks(visitId: nil, homeBobEmployeeId: nil, houseOwnerId: nil, isBlocked: nil, startTimeUtc: "2020-12-01T08:05:00", endTimeUtc: "2020-12-01T08:35:00", title: nil, isReviewed: nil, isFirstVisit: nil, isManual: nil, visitTimeUsed: nil, rememberToday: nil, houseOwnerFirstName: "Tone", houseOwnerLastName: "Holtermann", houseOwnerMobilePhone: nil, houseOwnerAddress: "Akademivej 15, 1 th", houseOwnerZip: "2800", houseOwnerCity: "Kgs. Lyngby", houseOwnerLatitude: 55.778830, houseOwnerLongitude: 12.521240, isSubscriber: nil, rememberAlways: nil, professional: nil, visitState: .done, stateOrder: nil, expectedTime: nil, tasks: [tasks], houseOwnerAssets: nil, visitAssets: nil, visitMessages: nil, distance: "0 Km")

        sut = HomeTableCellViewModel(dayTasks: dayTask)
    }
    
    override func tearDown() {
        sut = nil
    }
    
    func testViewModelNotNil() {
        XCTAssertNotNil(sut)
    }
    
    func testPropertiesWithoutNil() {
        XCTAssertEqual(sut.name, "Tone Holtermann", "Name should be Tone Holtermann")
        XCTAssertEqual(sut.status, "Done", "Status should be Done")
        XCTAssertEqual(sut.statusBgColour, UIColor.doneOption, "StatusBgColour should be UIColor.doneOption")
        XCTAssertEqual(sut.tasks, "Pudsning indvendig", "Task title should be Pudsning indvendig")
        XCTAssertEqual(sut.arrivalTime, "08:05", "Arrival time should be 08:05")
        XCTAssertEqual(sut.destination, "Akademivej 15, 1 th Kgs. Lyngby 2800", "Destination should be Akademivej 15, 1 th Kgs. Lyngby 2800")
        XCTAssertEqual(sut.timeRequired, "25", "TimeRequired should be 25")
        XCTAssertEqual(sut.distance, "0 Km", "Distance should be 0 Km")
    }
}
