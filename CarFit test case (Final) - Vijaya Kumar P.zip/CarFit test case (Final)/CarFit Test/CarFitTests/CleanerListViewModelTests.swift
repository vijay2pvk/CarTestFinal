//
//  CleanerListViewModelTests.swift
//  CarFitTests
//
//  Created by Pandurangan, Vijaya Kumar on 07/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import XCTest
@testable import CarFit

class CleanerListViewModelTests: XCTestCase {

    var sut: CleanerListViewModel!

    override func setUp() {
        sut = CleanerListViewModel()
    }

    override func tearDown() {
        sut = nil
    }

    func testViewModelNotNil() {
        XCTAssertNotNil(sut)
    }

    func testFetchRequest() {
        let exp = expectation(description: "Trigger should complete")
        sut.fetchCleanerList { result  in
            if case .failure(let error) = result {
                XCTFail("error in retrival, \(error.localizedDescription)")
            }
            exp.fulfill()
        }
        waitForExpectations(timeout: 0.01)
    }

    func testCellViewModelsProperty() {
        let exp = expectation(description: "Trigger should complete")
        sut.fetchCleanerList { _ in exp.fulfill()}
        waitForExpectations(timeout: 0.01)

        sut.filterListFor(date: "2020-12-01")

        let expectedModel = sut.viewModelForItem(at: IndexPath(row: 0, section: 0))
        XCTAssertNotNil(expectedModel)
        XCTAssertEqual(sut.selectedDayTasksListCount(), 3, "Count should be 3")
    }
}
