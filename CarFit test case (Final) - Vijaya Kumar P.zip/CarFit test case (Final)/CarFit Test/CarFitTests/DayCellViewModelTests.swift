//
//  DayCellViewModelTests.swift
//  CarFitTests
//
//  Created by Pandurangan, Vijaya Kumar on 07/12/20.
//  Copyright © 2020 Test Project. All rights reserved.
//

import XCTest
@testable import CarFit

class DayCellViewModelTests: XCTestCase {
    
    var sut: DayCellViewModel!
    
    override func setUp() {
        sut =  DayCellViewModel(dayCellModel: DayModel(day: "10", weekDay: "Thu", date: "2020-12-10"))
    }
    
    override func tearDown() {
        sut = nil
    }
    
    func testViewModelNotNil() {
        XCTAssertNotNil(sut)
    }
    
    func testProperties() {
        XCTAssertEqual(sut.day, "10", "Day should be 10")
        XCTAssertEqual(sut.weekday, "Thu", "Weekday should be Thu")
        XCTAssertEqual(sut.date, "2020-12-10", "Date should be 2020-12-10")
    }
}
